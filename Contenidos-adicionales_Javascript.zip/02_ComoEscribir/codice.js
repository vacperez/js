// Prova 1

// Costante di tipo testo
const msgHello = 'Buongiorno mondo';

// Ricerco nel DOM il div con ID = 'output' e ne assegno il contenuto
document.getElementById('output').innerHTML = msgHello;