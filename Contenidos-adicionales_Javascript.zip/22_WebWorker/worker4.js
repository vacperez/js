let i;
onmessage = function (event) {
    i = event.data;
};

portMessage(i);
