﻿
var applicazione = "Appname: " + navigator.appName + "; AppVesion: " + navigator.appVersion + "; Platform: " + navigator.platform + ";  UserArgent: " + navigator.userAgent;
var posto = location.hash;
postMessage(posto);
