﻿var i
onmessage = function(event) {
    i = event.data;
}
//setInterval(generaSequenza, 300);

		portMessage(i);
	

